import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Integers {
	
	private int n1 = 0;
	private int n2 = 0;
	private BufferedReader br;
	
	//Lee los numeros ingresados por el usuario
	private void readNumbers() throws IOException{
		
		br = new BufferedReader(new InputStreamReader(System.in));
		
	    System.out.println("Ingrese numero 1: ");
	    n1 = Integer.parseInt(br.readLine());
	    System.out.println("Ingrese numero 2: ");
	    n2 = Integer.parseInt(br.readLine());
	}
	
	//Dice si es par o no
	private void isEven(int n){
		
         if(n % 2 == 0){
			
			System.out.println("El numero " + n +  " es PAR");
		}else{
			
			System.out.println("El numero " + n +  " es IMPAR");
		}
		
	}
	//Dice cual es el maximo 
	private void max(int a, int b){
		
		if(a > b){
			
			 System.out.println(a + " es mayor que " + b);
		}else if(a == b){
			
			System.out.println("Los numeros dados son iguales");
		}else {
			
			System.out.println(b + " es mayor que " + a);
		}
		
	}
	//Halla si A es multiplo o no de B
	private void isAMultipleOfB(int a, int b){
		
		if(a % b == 0 ){
			
			System.out.println(a + " ES multiplo de " + b);
		}else {
			
			System.out.println(a + " NO es multiplo de " + b);
		}
	}
	//Corre todas los metodos
	public void run() throws IOException{
		
		 readNumbers();
		 isEven(n1);
		 isEven(n2);
		 max(n1, n2);
		 isAMultipleOfB(n1, n2);
		
	}

}
