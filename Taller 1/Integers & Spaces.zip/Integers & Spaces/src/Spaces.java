import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Spaces {
	
	private int number = 0;
	private ArrayList<Integer> digits;
	private BufferedReader br;
	
	//Pide el numero
	private void readNumber() throws NumberFormatException, IOException{
		
		br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Ingrese un numero entero: ");
		number = Integer.parseInt(br.readLine());
	}
	
	private ArrayList<Integer> findDigits(){
		
		boolean quit = false;
		double digit = number;
		int decimals = 1;
	    digits = new ArrayList<Integer>();
		//Divide de diez en diez y guarda el digito que es menor a 10
	    //hasta terminar el numero de dijitos.
		while(!quit){
			
			if(number < 10){
				
				digits.add(number);
				quit = true;
				break;
			}
			
			if(digit < 10){
				
				int digitToAdd = (int)Math.floor(digit);
				digits.add(digitToAdd);
				number = number - (digitToAdd * decimals);
				digit = number;
				decimals = 1;
			}else {
			
			digit = digit / 10;
			decimals = decimals * 10;
		  }
		}
		
		return digits;
	}
	//Imprime los numeros guardados en la lista digits
	private void printDigits(){
		
		
	    for(int i = 0; i < digits.size(); i++){
	    	
	    	System.out.print(digits.get(i) + "   ");
	    }
		
	}
	
	public void run() throws NumberFormatException, IOException{
		
		readNumber();
		findDigits();
		printDigits();
		
	}

}
