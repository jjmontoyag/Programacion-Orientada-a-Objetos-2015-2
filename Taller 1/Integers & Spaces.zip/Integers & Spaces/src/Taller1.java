import java.io.IOException;

public class Taller1 {

	public static void main(String[] args) throws IOException {

     //*****INTEGERS*********************//
		//Integers integers = new Integers();
		//integers.run();
		
	
	 //****SPACES***********************//
		// Spaces spaces = new Spaces();
		// spaces.run();
        
	}

}
